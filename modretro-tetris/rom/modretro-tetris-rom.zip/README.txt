MODRETRO TETRIS — Native Game Boy Color (.gbc) Cartridge ROM
=============================================================
File: modretro-tetris.gbc (32,768 bytes, CGB+DMG Dual Mode 0x80)

HOW TO RUN ON MODRETRO CHROMATIC:
1. Unzip this archive first (EverDrive & flashcarts require the uncompressed .gbc file).
2. Flashcart (EverDrive-GB X7 / EZ-Flash Jr.):
   Copy `modretro-tetris.gbc` onto your FAT32 microSD card and launch it on your ModRetro Chromatic.
3. Reflashable GBC Cartridge:
   Flash `modretro-tetris.gbc` to any 32KB+ reflashable GBC cart via GBxCart RW or Joey Jr.
4. Emulator (Desktop / Mobile):
   Open `modretro-tetris.gbc` in SameBoy, mGBA, BGB, OpenEmu, or Delta.

CONTROLS:
- D-Pad Left / Right : Move piece (with DAS)
- D-Pad Down         : Soft drop (+1 pt/cell)
- D-Pad Up           : Hard drop (+2 pts/cell)
- A Button           : Rotate Clockwise
- B Button           : Rotate Counter-Clockwise
- SELECT             : Hold / Swap Piece (or toggle music while paused)
- START              : Start / Pause / Restart

Source & live web handheld:
https://tongfangsun-collab.github.io/modretro-tetris/
