CHAIRMAN'S ADVENTURE — Native Game Boy Color (.gbc) Cartridge ROM
=================================================================
Starring Chairman (fluffy cream dog in a black quilted vest with red trim)!
File: chairman-adventure.gbc (32,768 bytes, CGB+DMG Dual Mode 0x80)

HOW TO PLAY ON MODRETRO CHROMATIC:
1. Unzip this archive first (flashcarts require the uncompressed .gbc file).
2. EverDrive-GB X7 / EZ-Flash Jr.: Copy `chairman-adventure.gbc` to your FAT32 microSD card.
3. Reflashable GBC Cartridge: Flash `chairman-adventure.gbc` via GBxCart RW or Joey Jr.
4. Emulators: Open `chairman-adventure.gbc` in SameBoy, mGBA, BGB, OpenEmu, or Delta.

CONTROLS:
- D-Pad Left / Right : Run
- A Button           : Jump (Double Jump supported!)
- B Button           : Throw Spinning Bone Boomerang
- SELECT             : Stage Select on Title (1:LION, 2:TIGER, 3:ELEPHANT)
- START              : Start / Pause / Next Stage

Play online & source code:
https://tongfangsun-collab.github.io/modretro-chairman/
